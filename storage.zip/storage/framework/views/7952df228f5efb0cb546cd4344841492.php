<?php

$id=isset($datas) && !empty($datas) ? $datas->id:'';
$categories=isset($datas) && !empty($datas) ? $datas->loan_category:'';
$persntage=isset($datas) && !empty($datas) ? $datas->percentage:'';

?>
<div class="card-body">
        <h1 class="text-center">Loan Categories</h1>
        <form method="Post" id="categories_create" action="<?php echo e(url('insert-category')); ?>" enctype="multipart/form-data" >
            <!-- Loan Details -->
             <?php echo csrf_field(); ?>
             <input type="text" hidden name="categories_id" id="categories_id" value="<?php echo e($id); ?>">
             
            <div class="mb-3">
                <label for="loanAmount" class="form-label">Categories:</label>
                <input type="text" name="loan_category" class="form-control" id="loan_category" placeholder="Enter categories name" required  value="<?php echo e($categories); ?>">
            </div>

            <div class="mb-3">
                <label for="loanAmount" class="form-label">Persantage :</label>
                <input type="number" name="percentage" class="form-control" id="percentage" placeholder="Enter categories amount" required value="<?php echo e($persntage); ?>">
            </div>
            
            <!-- Terms and Conditions -->
            <div class="mb-3 form-check">
            <input 
        type="checkbox" 
        class="form-check-input" 
        id="infoAgreement" 
        required 
        <?php echo e($persntage !== '' ? 'checked' : ''); ?>

    >
                <label  class="form-check-label" for="infoAgreement">I agree that the information provided is true and accurate.</label>
              
            </div>
            <!-- <div class="mb-3 form-check">
    <input 
        type="checkbox" 
        class="form-check-input" 
        id="infoAgreement" 
        required 
        <?php echo e($persntage !== '' ? 'checked' : ''); ?>

    >
    <label class="form-check-label" for="infoAgreement">I agree to the terms and conditions</label>
</div> -->

          

          <!--   <button type="submit" class="btn btn-success w-100">Submit Application</button> -->
            <!-- <button type="submit" onclick="save(this)" class="btn btn-primary btn-block" redirect="#">Save</button> -->
            <button type="submit" onclick="save(this)" class="btn btn-primary btn-block" redirect="#">Save</button>
        </form>
    </div>
   

<?php /**PATH C:\Users\Muhammad Sagor\Herd\sunriseloan\resources\views/admin/categorys/categories_create_form.blade.php ENDPATH**/ ?>