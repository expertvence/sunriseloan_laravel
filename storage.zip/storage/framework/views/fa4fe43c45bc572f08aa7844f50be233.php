
<link rel="stylesheet" href="<?php echo e(asset('datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">

<style>
    td {
        padding: 5px;
    }
</style>

        <div class="container">
            <div class="form-row justify-content-center">
                <div class="col-lg-12">
                    <div class="card shadow-lg border-0 rounded-lg ">
                       
                        <div class="card-body">
                        <?php echo $__env->make('admin/loan_commit/loan_commit_form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                           
                        </div>
                    </div>

                </div>
            </div>
        </div>
  

    <script type="application/javascript" src="<?php echo e(asset('datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $('.date_picker').datepicker({
            format: 'dd-mm-yyyy',
            autoclose: true,
            todayHighlight: true,
            clearBtn: true

        });
      
    </script>
<?php /**PATH C:\Users\Muhammad Sagor\Herd\sunriseloan\resources\views/admin/loan_commit/loan_commit.blade.php ENDPATH**/ ?>