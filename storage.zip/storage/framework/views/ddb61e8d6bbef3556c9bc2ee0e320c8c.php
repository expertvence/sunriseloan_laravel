
        <div class="container">
            <div class="form-row justify-content-center">
                <div class="col-lg-12">
                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                        <div class="card-header">
                            <h3 class="text-center font-weight-light my-4">Create Account</h3>
                        </div>
                        <?php echo $__env->make('admin/memberReg/reg_create_form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    </div>
                </div>
            </div>
        </div>


<?php /**PATH C:\Users\Muhammad Sagor\Herd\sunriseloan\resources\views/admin/memberReg/register.blade.php ENDPATH**/ ?>