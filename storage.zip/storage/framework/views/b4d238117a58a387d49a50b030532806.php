    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Member List
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="datatablesSimple" class="data-table table table-bordered " width="100%">
                    <thead class="thead-dark">
                        <tr>
                            <th>SL#</th>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Religion</th>
                            <th>Father's Name</th>
                            <th>Motherd's Name</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if(!empty($data)): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($value->Uid); ?></td>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e($value->age); ?></td>
                            <td><?php echo e($value->gender); ?></td>
                            <td><?php echo e($value->religion); ?></td>
                            <td><?php echo e($value->fathers_mane); ?></td>
                            <td><?php echo e($value->mothers_mane); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->address); ?></td>
                            <td class="text-center"><?php echo e($value->is_publish == 1 ? 'Active' : 'Diactive'); ?></td>
                            <td>
                                <a href="<?php echo e(route('member_profile',$value->id)); ?>" target="_blank" rel="noopener noreferrer"><i class="fas fa-user"></i></a>
                                <span class="btn btn-sm  open-modal btnView" data-action="<?php echo e(route('employee-member-register', $value->id)); ?>" data-modal="common-modal-md" data-title=" Member Edit" title="Edit" data-id="<?php echo e($value->id); ?>"><i class="fas fa-edit"></i></span>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                    </tbody>

                </table>
            </div>
        </div>
    </div>
<script>
    $(document).ready(function() {

        $(".data-table").DataTable({
            "ordering": true,
            "bAutoWidth": true,

        });
    });
</script><?php /**PATH C:\Users\Muhammad Sagor\Herd\sunriseloan\resources\views/employee/memberRegister/member_list.blade.php ENDPATH**/ ?>