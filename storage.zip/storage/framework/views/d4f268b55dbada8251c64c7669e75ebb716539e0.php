<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="sb-nav-fixed mainContant">
	
		<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div id="layoutSidenav">
			<div id="layoutSidenav_nav">
				<?php echo $__env->make('layouts.sideber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
			<div id="layoutSidenav_content">
				<div class="<?php echo e(auth()->user() ? 'content-wrapper' : ''); ?>">
					<main id="page-content">
						<!-- <?php echo $__env->yieldContent('content'); ?> -->
					</main>
				</div>
				<footer class="py-4 bg-light mt-auto">
					<div class="container-fluid px-4">
						<div class="d-flex align-items-center justify-content-between small">
							<div class="text-muted">Copyright &copy; <span id="year-show"></span> <strong>Powered By - [Md Sagor Hossain]</strong></div>
							<div>
								<a href="#">Privacy Policy</a>
								&middot;
								<a href="#">Terms &amp; Conditions</a>
							</div>
						</div>
					</div>
				</footer>
			</div>
		</div>
	
	<?php echo $__env->make('layouts.open_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<script>
	let YearShow= new Date().getFullYear();
	document.getElementById('year-show').textContent=YearShow;
</script><?php /**PATH C:\Users\Muhammad Sagor\Herd\sunriseloan\resources\views/layouts/master.blade.php ENDPATH**/ ?>