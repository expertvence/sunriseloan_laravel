<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
   Loan Request
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="datatablesSimple" class="data-table table table-bordered " width="100%">
                <thead class="thead-dark">
                    <tr>
                        <th>SL#</th>
                        <th>Name</th>
                        <th>Persentage</th>
                        
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(!empty($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($value->loan_category); ?></td>
                        <td><?php echo e($value->percentage); ?></td>
                        

                        <!-- Status Update -->
                        

                        <td>
                            <form action="<?php echo e(route('delete', $value->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?> <!-- Use DELETE method here -->
                                <span class="btn btn-sm open-modal btnView" data-action="<?php echo e(route('edit-category', $value->id)); ?>" data-modal="common-modal-md" data-title="Categories Edit" title="Edit" data-id="<?php echo e($value->id); ?>">
                                <i class="fas fa-edit"></i>
                            </span>
                                <button type="submit" style="border: none; background: none; padding: 0; outline: none;">
                                    <i class="fas fa-trash" style="color: red;"></i>
                                </button>
                            
                                
                            </form>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
<script>
    $(document).ready(function() {
        $(".data-table").DataTable({
            "ordering": true,
            "bAutoWidth": true,
        });
    });
<?php /**PATH C:\Users\Muhammad Sagor\Herd\sunriseloan\resources\views/admin/categorys/categories_list.blade.php ENDPATH**/ ?>